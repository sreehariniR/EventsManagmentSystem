import { useState } from "react"
import { useNavigate } from "react-router-dom"

type LoginData ={
    email:string
    password:string
}

export default function Login(){

    const navigate = useNavigate()

    const [login,setLogin] = useState<LoginData>({
        email:"",
        password:""
    })

    const loginForm = async () => {

        try{

            const res = await fetch("http://localhost:8082/facultylogin/",{
                method:"POST",
                headers:{"Content-Type":"application/json"},
                body:JSON.stringify(login)
            })

            if(!res.ok){
                throw new Error("Login Failed")
            }

            // backend returns LIST OF EVENTS
            const events = await res.json()

            navigate("/events",{state:{events}})

        }catch(err){
            alert("Invalid Credentials")
        }

    }

    return(
        <div
        className="min-h-screen bg-cover bg-center flex items-center justify-center"
        style={{backgroundImage:"url('/background.jpg')"}}
        >

            <div className="bg-indigo-50 p-10 rounded-xl w-[350px] shadow-xl">

                <h1 className="text-2xl font-bold text-indigo-600 mb-6 text-center">
                    Faculty Login
                </h1>

                <input
                type="text"
                placeholder="Email"
                className="w-full p-2 mb-4 border rounded-lg"
                onChange={(e)=>setLogin({...login,email:e.target.value})}
                />

                <input
                type="password"
                placeholder="Password"
                className="w-full p-2 mb-6 border rounded-lg"
                onChange={(e)=>setLogin({...login,password:e.target.value})}
                />

                <button
                className="w-full bg-indigo-300 p-2 rounded-lg"
                onClick={loginForm}
                >
                Login
                </button>

            </div>
        </div>
    )
}