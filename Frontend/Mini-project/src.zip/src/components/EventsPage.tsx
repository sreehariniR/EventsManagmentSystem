import { useLocation, useNavigate } from "react-router-dom"

type Event ={
    id:string
    studentName:string
    rollNo:string
    eventName:string
    eventDate:string
    eventLocation:string
    eventDescription:string
    facultyID:string
}

export default function EventsPage(){

    const location = useLocation()
    const navigate = useNavigate()

    const events:Event[] = location.state?.events || []

    return(

        <div
        className="min-h-screen bg-cover bg-center p-10"
        style={{backgroundImage:"url('/background.jpg')"}}
        >

            <div className="bg-blue-50 p-10 rounded-xl shadow-xl">

                <h1 className="text-2xl font-bold text-blue-600 mb-6 text-center">
                    Faculty Events
                </h1>

                <div className="flex gap-4 mb-6 justify-center">

                    <button
                    className="bg-yellow-300 px-4 py-2 rounded"
                    onClick={()=>navigate("/register")}
                    >
                    Register Event
                    </button>

                    <button
                    className="bg-green-300 px-4 py-2 rounded"
                    onClick={()=>navigate("/update")}
                    >
                    Update Event
                    </button>

                    <button
                    className="bg-red-300 px-4 py-2 rounded"
                    onClick={()=>navigate("/delete")}
                    >
                    Delete Event
                    </button>

                </div>

                <table className="w-full border">

                    <thead className="bg-blue-200">
                        <tr>
                            <th className="p-2">Student</th>
                            <th className="p-2">Roll</th>
                            <th className="p-2">Event</th>
                            <th className="p-2">Date</th>
                            <th className="p-2">Location</th>
                        </tr>
                    </thead>

                    <tbody>

                        {events.map((e)=>(
                            <tr key={e.id} className="border text-center">

                                <td>{e.studentName}</td>
                                <td>{e.rollNo}</td>
                                <td>{e.eventName}</td>
                                <td>{e.eventDate}</td>
                                <td>{e.eventLocation}</td>

                            </tr>
                        ))}

                    </tbody>

                </table>

            </div>

        </div>
    )
}