import { BrowserRouter,Routes,Route } from "react-router-dom"

import Login from "./components/Login"
import EventsPage from "./components/EventsPage"
import RegisterEvent from "./components/RegisterEvent"
import UpdateEvent from "./components/UpdateEvent"
import DeleteEvent from "./components/DeleteEvent"

function App(){

return(

<BrowserRouter>

<Routes>

<Route path="/" element={<Login/>}/>
<Route path="/events" element={<EventsPage/>}/>
<Route path="/register" element={<RegisterEvent/>}/>
<Route path="/update" element={<UpdateEvent/>}/>
<Route path="/delete" element={<DeleteEvent/>}/>

</Routes>

</BrowserRouter>

)

}

export default App