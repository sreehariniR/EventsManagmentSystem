package org.example.student.controller;

import org.example.events.model.EventModel;
import org.example.student.model.LoginModel;
import org.example.student.service.LoginService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/login")
public class LoginController {
    public final LoginService loginService;
    public LoginController(LoginService loginService){
        this.loginService=loginService;
    }

    @GetMapping("/")
    public List<EventModel> fetchEvents(@RequestBody LoginModel login){
        return loginService.fetchEvents(login);
    }
}
