import { useState } from "react"
import { useLocation } from "react-router-dom"

type FacultyData={
    facultyID:string
}

export default function UpdateEvent(){

    const location = useLocation()
    const faculty = location.state as FacultyData

    const [rollNo,setRollNo]=useState("")
    const [eventName,setEventName]=useState("")

    const [updated,setUpdated]=useState({
        studentName:"",
        eventDate:"",
        eventLocation:"",
        eventDescription:""
    })

    const updateEvent = async()=>{

        const payload={
            ...updated,
            rollNo,
            eventName,
            facultyID:faculty.facultyID
        }

        const res = await fetch(
        `http://localhost:8082/faculty/${faculty.facultyID}/${rollNo}/${eventName}`,
        {
            method:"PUT",
            headers:{"Content-Type":"application/json"},
            body:JSON.stringify(payload)
        })

        if(res.ok){
            alert("Updated")
        }

    }

    return(

        <div className="min-h-screen bg-cover bg-center flex items-center justify-center"
        style={{backgroundImage:"url('/background.jpg')"}}
        >

        <div className="bg-green-50 p-10 rounded-xl shadow-xl w-[420px]">

        <h1 className="text-2xl font-bold text-green-700 mb-6 text-center">
        Update Event
        </h1>

        <input placeholder="Roll No" className="input"
        onChange={(e)=>setRollNo(e.target.value)}/>

        <input placeholder="Event Name" className="input"
        onChange={(e)=>setEventName(e.target.value)}/>

        <input placeholder="New Location" className="input"
        onChange={(e)=>setUpdated({...updated,eventLocation:e.target.value})}/>

        <textarea placeholder="New Description" className="input"
        onChange={(e)=>setUpdated({...updated,eventDescription:e.target.value})}/>

        <button
        className="w-full bg-green-300 p-2 rounded-lg mt-3"
        onClick={updateEvent}>
        Update
        </button>

        </div>
        </div>
    )
}