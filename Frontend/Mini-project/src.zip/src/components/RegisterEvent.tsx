import { useState } from "react"
import { useLocation } from "react-router-dom"

type EventData ={
    studentName:string
    rollNo:string
    eventName:string
    eventDate:string
    eventLocation:string
    eventDescription:string
}

type FacultyData ={
    facultyID:string
}

export default function RegisterEvent(){

    const location = useLocation()
    const faculty = location.state as FacultyData

    const [event,setEvent] = useState<EventData>({
        studentName:"",
        rollNo:"",
        eventName:"",
        eventDate:"",
        eventLocation:"",
        eventDescription:""
    })

    const registerEvent = async () =>{

        const payload = {
            ...event,
            facultyID:faculty.facultyID
        }

        const res = await fetch("http://localhost:8082/faculty/events",{
            method:"POST",
            headers:{"Content-Type":"application/json"},
            body:JSON.stringify(payload)
        })

        if(res.ok){
            alert("Event Registered Successfully")
        }else{
            alert("Registration Failed")
        }

    }

    return(

        <div
        className="min-h-screen bg-cover bg-center flex items-center justify-center"
        style={{backgroundImage:"url('/background.jpg')"}}
        >

            <div className="bg-yellow-50 p-10 rounded-xl w-[420px] shadow-xl">

                <h1 className="text-2xl font-bold text-yellow-700 mb-6 text-center">
                    Register Event
                </h1>

                <input
                type="text"
                placeholder="Student Name"
                className="w-full p-2 mb-3 border rounded-lg"
                onChange={(e)=>setEvent({...event,studentName:e.target.value})}
                />

                <input
                type="text"
                placeholder="Roll Number"
                className="w-full p-2 mb-3 border rounded-lg"
                onChange={(e)=>setEvent({...event,rollNo:e.target.value})}
                />

                <input
                type="text"
                placeholder="Event Name"
                className="w-full p-2 mb-3 border rounded-lg"
                onChange={(e)=>setEvent({...event,eventName:e.target.value})}
                />

                <input
                type="date"
                className="w-full p-2 mb-3 border rounded-lg"
                onChange={(e)=>setEvent({...event,eventDate:e.target.value})}
                />

                <input
                type="text"
                placeholder="Event Location"
                className="w-full p-2 mb-3 border rounded-lg"
                onChange={(e)=>setEvent({...event,eventLocation:e.target.value})}
                />

                <textarea
                placeholder="Event Description"
                className="w-full p-2 mb-4 border rounded-lg"
                onChange={(e)=>setEvent({...event,eventDescription:e.target.value})}
                />

                <button
                className="w-full bg-yellow-300 p-2 rounded-lg hover:bg-yellow-400"
                onClick={registerEvent}
                >
                Submit
                </button>

            </div>

        </div>
    )
}