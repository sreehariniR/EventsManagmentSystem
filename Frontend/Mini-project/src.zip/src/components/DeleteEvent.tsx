import { useState } from "react"
import { useLocation } from "react-router-dom"

type FacultyData={
    facultyID:string
}

export default function DeleteEvent(){

    const location = useLocation()
    const faculty = location.state as FacultyData

    const [rollNo,setRollNo]=useState("")
    const [eventName,setEventName]=useState("")

    const deleteEvent = async()=>{

        const res = await fetch(
        `http://localhost:8082/faculty/${faculty.facultyID}/${rollNo}/${eventName}`,
        {method:"DELETE"})

        if(res.ok){
            alert("Event Deleted")
        }

    }

    return(

        <div className="min-h-screen bg-cover bg-center flex items-center justify-center"
        style={{backgroundImage:"url('/background.jpg')"}}
        >

        <div className="bg-red-50 p-10 rounded-xl shadow-xl w-[350px]">

        <h1 className="text-2xl font-bold text-red-700 mb-6 text-center">
        Delete Event
        </h1>

        <input placeholder="Roll No" className="input"
        onChange={(e)=>setRollNo(e.target.value)}/>

        <input placeholder="Event Name" className="input"
        onChange={(e)=>setEventName(e.target.value)}/>

        <button
        className="w-full bg-red-300 p-2 rounded-lg mt-3"
        onClick={deleteEvent}>
        Delete
        </button>

        </div>
        </div>
    )
}